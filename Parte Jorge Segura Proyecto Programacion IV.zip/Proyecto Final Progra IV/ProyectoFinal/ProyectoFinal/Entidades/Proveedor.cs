﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.Entidades
{
    public class Proveedor
    {

        public int idProveedor { get; set; }

        public string desProveedor { get; set; }
        
        public int codTipoProveedor { get; set; }


    }
}
