﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoFinal.Entidades
{
    class Ingreso
    {
        public int idRegistro { get; set; }

        public double ingreso { get; set; }

        public double gasto { get; set; }

        public int dAhorro { get; set; }

        public string detalle { get; set; }

    }
}
