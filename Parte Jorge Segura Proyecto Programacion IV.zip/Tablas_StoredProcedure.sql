use prograIV

create table finanza(
IdRegistro int not null primary key,
ingreso decimal not null,
gasto decimal not null,
dahorros decimal not null,
detalle varchar(50)
)




CREATE PROCEDURE SP_AddFinanza
(
@ValIngreso decimal,  @ValGasto decimal, @ValAhorro decimal, @ValDetalle VARCHAR(50)
)
AS
BEGIN
SET NOCOUNT ON;
SELECT  ingreso, gasto,dahorros
FROM dbo.finanza
WHERE ingreso=@ValIngreso AND gasto=@ValGasto AND dahorros =@ValAhorro
end


CREATE PROCEDURE SP_EliminarRegistro
(
@ValIngreso decimal,  @ValGasto decimal, @ValAhorro decimal, @ValDetalle VARCHAR(50), @ValRegistro int
)

AS

delete Finanza where idRegistro= @ValRegistro

go



CREATE PROCEDURE SP_Actualizarregistro
(

@ValIngreso decimal,  @ValGasto decimal, @ValAhorro decimal, @ValDetalle VARCHAR(50), @ValRegistro int
)
as 

Update finanza set IdRegistro = @ValRegistro, 
ingreso = @ValIngreso , gasto = @ValGasto , 
dahorros = @ValAhorro , detalle = @ValDetalle